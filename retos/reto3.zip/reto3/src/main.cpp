#include <iostream>
#include "ejercicio1.h"


using namespace std;

int main(){


}
