//
// Created by flo on 23/11/22.
//

#ifndef RETO3_EJERCICIO2_H
#define RETO3_EJERCICIO2_H
using namespace  std;

#include <vector>

template <class T>


#endif //RETO3_EJERCICIO2_H
