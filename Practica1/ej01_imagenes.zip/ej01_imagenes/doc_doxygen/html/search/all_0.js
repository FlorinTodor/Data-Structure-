var searchData=
[
  ['adjustcontrast_0',['AdjustContrast',['../classImage.html#a4884f3eb51efdecc005092534ba7e4ea',1,'Image']]]
];
